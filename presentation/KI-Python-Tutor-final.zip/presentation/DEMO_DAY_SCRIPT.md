# Demo Day Sprecher-Skript — KI Python Tutor
**Gesamt: ~7 Minuten | Emad Almousa**

---

## Slide 1 — Titel (~20 Sekunden)

> "Hallo, ich bin Emad. Ich habe den KI Python Tutor entwickelt — ein agentenbasiertes Lernsystem,
> das Python-Lernende mit personalisiertem Feedback, Code-Review und einem Skill-Tracking-System
> begleitet. Ich zeige euch heute zuerst kurz das Problem, dann direkt die Live-Demo."

---

## Slide 2 — Problem & Lösung (~60 Sekunden)

> "Wer schon mal Python gelernt hat, kennt das Gefühl: Man weiß nicht, wo man steht.
> Der Compiler spuckt englische Fehlermeldungen aus, ohne zu erklären *warum* der Code falsch ist.
> Und jede neue KI-Chatsession beginnt bei Null — kein Kontext, kein Gedächtnis.
>
> Der KI Python Tutor löst genau das: Ein Skill-Tree mit 37 Skills zeigt den Fortschritt.
> Eine 3-stufige Code-Review-Chain erklärt Fehler auf Deutsch, mit Zeilennummer.
> Und das Agent-Gedächtnis erinnert sich an vergangene Sessions —
> *'Letzte Woche hattest du Schwierigkeiten mit Loops — heute machen wir weiter.'*"

---

## Slide 3 — Features / Was ich zeige (~40 Sekunden)

> "Das System hat 6 Kernfeatures — und ich zeige sie gleich alle live:
> Chat-Tutor mit ReAct-Agent, 3-stufige Code-Review, Skill-Tree mit Übungen und Hints,
> RAG-System für eigene PDFs, Agent-Gedächtnis, und den personalisierten Wochenlernplan.
> Genug erklärt — wechseln wir direkt zur Demo."

---

## Slide 4 — Architektur (~60 Sekunden)

> "Kurz zur Technik — die wichtigsten Entscheidungen:
>
> Das Frontend ist Next.js 14, das Backend FastAPI. Im Kern läuft ein LangChain ReAct-Agent,
> der je nach Nutzerfrage selbst entscheidet, welches Tool er aufruft —
> keine hardcodierten if-else-Flows.
>
> Für die Code-Review habe ich eine RunnableSequence gebaut: Schritt 1 gibt seinen Summary
> an Schritt 2 weiter, Schritt 2 an Schritt 3. Das ist quasi Chain-of-Thought für Code-Qualität.
>
> Das RAG-System nutzt FAISS lokal — kein externer Vektorservice, kein Datenschutzproblem.
> Und das Gedächtnis komprimiert jeden Chat-Turn auf 40 Wörter — kein Token-Overflow."

---

## Slide 6 — Live Demo (~220 Sekunden / ~3:40 min)

> *(Browser auf localhost:3000 öffnen)*

**Login & Dashboard (~20s)**
> "Ich logge mich ein — und sehe sofort das Dashboard mit meinem Fortschritt."

**Chat & Gedächtnis (~60s)**
> "Ich frage den Tutor: *'Erkläre mir List Comprehensions.'*
> *(warten)* — er antwortet mit Erklärung und Code-Beispiel.
> Was ihr hier seht: Der Agent hat Kontext aus vergangenen Sessions.
> Wenn ich frage *'Was haben wir zuletzt gemacht?'* — erinnert er sich."

**Code Review (~60s)**
> "Ich gebe Code mit einem kleinen Fehler ein und klicke Code Review.
> *(warten)* — ihr seht drei Stufen: Syntax, Stil, Best Practices.
> Jede Stufe mit Zeilennummer, Erklärung auf Deutsch, Verbesserungsvorschlag."

**Skills & Übung (~45s)**
> "Hier ist der Skill-Tree. Ich öffne eine Übung zu List Comprehensions.
> Wenn ich nicht weiterkomme — ich klicke auf Hint.
> Hint 1 ist allgemein, Hint 2 konkreter, Hint 3 zeigt fast die Lösung."

**Lernplan (~30s)**
> "Zum Schluss: der personalisierte Lernplan. Ein Klick — und der Agent generiert
> einen Wochenlernplan basierend auf meinen schwachen Skills. Gecacht für 28 Tage."

---

## Slide 5 — Reflexion (~40 Sekunden)

> "Was habe ich gelernt? Prompt Engineering ist der eigentliche Engpass — nicht der Code.
> Das Prompt entscheidet, ob die KI brauchbare Antworten gibt.
>
> Was würde ich anders machen? Streaming von Anfang an einplanen — Antworten kommen
> sonst nach 3–8 Sekunden. Und pgvector statt FAISS für Produktion.
>
> Nächste Schritte: Streaming via SSE, adaptive Übungsschwierigkeit, bessere UX.
>
> Danke — ich bin gespannt auf eure Fragen."

---

*Zeitübersicht: 20s + 60s + 40s + 60s + 220s + 40s = 440s ≈ 7:20 min*
