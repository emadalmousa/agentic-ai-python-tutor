# HTML-Präsentation als PDF exportieren

## Schritte

1. **Browser öffnen**
   Öffne `presentation/demoday.html` direkt im Browser (Datei-Pfad in die Adressleiste ziehen
   oder `File → Open File`). Chrome oder Edge empfohlen.

2. **Vollbild prüfen**
   Stelle sicher, dass du **nicht** im Vollbild-Modus bist (kein F-Taste-Vollbild).
   Die Slides sollen im normalen Browserfenster zu sehen sein.

3. **Drucken öffnen**
   `Strg + P` (Windows/Linux) oder `Cmd + P` (Mac).

4. **Einstellungen im Druckdialog**

   | Einstellung | Wert |
   |---|---|
   | Ziel / Drucker | **Als PDF speichern** |
   | Ausrichtung | **Querformat (Landscape)** |
   | Papierformat | A4 oder Letter |
   | Ränder | **Keine** (None) |
   | Hintergrundgrafiken | **Aktiviert** (Häkchen setzen!) |
   | Maßstab | 100 % |

   > Das Häkchen bei **"Hintergrundgrafiken"** ist wichtig — sonst fehlen Farben und Karten-Hintergründe.

5. **Speichern**
   Dateiname: `demo_day_ki_python_tutor.pdf`
   Speicherort: `presentation/demo_day_ki_python_tutor.pdf`

6. **Prüfen**
   Öffne die PDF kurz und checke: Sind alle 6 Slides vorhanden? Stimmen Farben und Layout?

---

## Alternativ: export_pdf.js (falls vorhanden)

Falls das Skript `presentation/export_pdf.js` existiert und Node.js + Puppeteer installiert sind:

```bash
cd presentation
node export_pdf.js
```

Das Skript exportiert die Slides automatisch als PDF mit korrekten Maßen.
